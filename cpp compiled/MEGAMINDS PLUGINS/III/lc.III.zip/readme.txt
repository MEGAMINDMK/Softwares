=================MEGAMIND MODS===================
1.This trainer is used to spawn cars
by pressing END key in game

2.trainer requires gta 3 patch 1.0

3.copy the file lc.III.asi to your gta 3
root directory/ur gta 3 folder

4.enjoy....